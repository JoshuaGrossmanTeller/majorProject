#ifndef MAIN_CPP
#define MAIN_CPP

using namespace std;
#include "raylib.h"
#include "raymath.h"
#include <iostream>
#include <string>
#include "mathQuestion.hpp"
#define MAX_INPUT_CHARS 9
#include "mathQQueue.hpp"
#include <vector>
#include <cmath>


int main(void){

    //screen size
    const int screenWidth = 800;
    const int screenHeight = 450;


   //create queue
   mathQQueue lineofQ;
 
   //initialize all questions
   //addition
   mathQuestion q1 = mathQuestion(1);
   mathQuestion q2 = mathQuestion(1);
   mathQuestion q3 = mathQuestion(1);
   mathQuestion q4 = mathQuestion(1);
   mathQuestion q5 = mathQuestion(1);
 
//add questions to the queue;
    lineofQ.enqueue(q1);
    lineofQ.enqueue(q2);
    lineofQ.enqueue(q3);
    lineofQ.enqueue(q4);
    lineofQ.enqueue(q5);


Node* currentPoint;
mathQuestion currentQ;
std::string qText;
std::string inputString = "";
char name[MAX_INPUT_CHARS + 1]= "\0";
int userAnswer = 0;
int letterCount = 0;
Rectangle textBox = { screenWidth/2.0f - 100, 180+140, 225, 50 };
bool mouseOnText = false;
int framesCounter = 0;

InitWindow(screenWidth, screenHeight, "Math Questions Game");
SetTargetFPS(60);

int posX = 100;
int posY = 100;


while(!WindowShouldClose()){
    BeginDrawing();
    ClearBackground(RAYWHITE);


    while(!lineofQ.isEmpty()){
        currentPoint = lineofQ.getFront();
        currentQ = currentPoint->data;
        qText = currentQ.getQuestion();

       //draw the text of the question on the screen
       DrawText(qText.c_str(), 325, 350, 20, DARKGRAY);
       DrawText(("Your answer: " + inputString).c_str(), 325, 380, 20, DARKGRAY);

       if(IsKeyPressed(KEY_ENTER)){
                userAnswer = std::stoi(inputString);

            //START OF CORRECT/INCORRECT CODE
            if(currentQ.isCorrect(userAnswer)){ //might not work for ques
                DrawText(TextFormat("CORRECT", letterCount, MAX_INPUT_CHARS), 315, 250, 20, GREEN);
           }else{
               DrawText(TextFormat("INCORRECT", letterCount, MAX_INPUT_CHARS), 315, 250, 20, RED);
            }

            // END OF CORRECT/INCORRECT CODE

                inputString = ""; // Clear input string for next question
       }

        try {
        userAnswer= std::stoi(inputString);
    }
        catch (std::invalid_argument const &e) {
        std::cout << "Bad input: std::invalid_argument thrown" << '\n';
    }
        catch (std::out_of_range const &e) {
        std::cout << "Integer overflow: std::out_of_range thrown" << '\n';
    }
       if(currentQ.isCorrect(userAnswer)){
           lineofQ.dequeue();
           //draw text for correct screen
           //have the original question text go away
           ClearBackground(RAYWHITE);
}
else{
   //draw text for incorrect answer try again
}

}

//levelUp screen
DrawText("Congratulations! You've completed all questions in level 1! You're now beginning level 2.", 200, 200, 20, DARKGRAY);



//initialize all questions
       //subtraction
           mathQuestion q6 = mathQuestion(2);
           mathQuestion q7 = mathQuestion(2);
           mathQuestion q8 = mathQuestion(2);
           mathQuestion q9 = mathQuestion(2);
           mathQuestion q10 = mathQuestion(2);




//add questions to the queue;
lineofQ.enqueue(q6);
lineofQ.enqueue(q7);
lineofQ.enqueue(q8);
lineofQ.enqueue(q9);
lineofQ.enqueue(q10);




while(!lineofQ.isEmpty()){
        currentPoint = lineofQ.getFront();
        currentQ = currentPoint->data;
        qText = currentQ.getQuestion();

       //draw the text of the question on the screen
       DrawText(qText.c_str(), 325, 350, 20, DARKGRAY);
       DrawText(("Your answer: " + inputString).c_str(), 325, 380, 20, DARKGRAY);

       if(IsKeyPressed(KEY_ENTER)){
                userAnswer = std::stoi(inputString);
                inputString = ""; // Clear input string for next question
       }


        try {
        userAnswer= std::stoi(inputString);
    }
        catch (std::invalid_argument const &e) {
        std::cout << "Bad input: std::invalid_argument thrown" << '\n';
    }
        catch (std::out_of_range const &e) {
        std::cout << "Integer overflow: std::out_of_range thrown" << '\n';
    }


       //draw the text of the question on the screen
       //take in users answer input w/ int userAnswer
       if(currentQ.isCorrect(userAnswer)){
           lineofQ.dequeue();
           //draw text for correct screen
           //have the original question text go away
}
else{
   //draw text for incorrect answer try again
}
}




//levelUp screen
DrawText("Congratulations! You've completed all questions in level 2! You're now beginning level 3.", 200, 200, 20, DARKGRAY);



//initialize all questions
       //multiplication
           mathQuestion q11 = mathQuestion(3);
           mathQuestion q12 = mathQuestion(3);
           mathQuestion q13 = mathQuestion(3);
           mathQuestion q14 = mathQuestion(3);
           mathQuestion q15 = mathQuestion(3);




//add questions to the queue;
lineofQ.enqueue(q11);
lineofQ.enqueue(q12);
lineofQ.enqueue(q13);
lineofQ.enqueue(q14);
lineofQ.enqueue(q15);




while(!lineofQ.isEmpty()){
        currentPoint = lineofQ.getFront();
        currentQ = currentPoint->data;
        qText = currentQ.getQuestion();

       //draw the text of the question on the screen
       DrawText(qText.c_str(), 325, 350, 20, DARKGRAY);
       DrawText(("Your answer: " + inputString).c_str(), 325, 380, 20, DARKGRAY);

       if(IsKeyPressed(KEY_ENTER)){
                userAnswer = std::stoi(inputString);
                inputString = ""; // Clear input string for next question
       }


        try {
        userAnswer= std::stoi(inputString);
    }
        catch (std::invalid_argument const &e) {
        std::cout << "Bad input: std::invalid_argument thrown" << '\n';
    }
        catch (std::out_of_range const &e) {
        std::cout << "Integer overflow: std::out_of_range thrown" << '\n';
    }
       if(currentQ.isCorrect(userAnswer)){
           lineofQ.dequeue();
           //draw text for correct screen
           //have the original question text go away
           ClearBackground(RAYWHITE);
}
else{
   //draw text for incorrect answer try again
   //DrawText(TextFormat("INCORRECT", letterCount, MAX_INPUT_CHARS), 315, 250, 20, RED);
}
 }


//beat the game screen

    EndDrawing();
}
CloseWindow();
return 0;


};
#endif