#ifndef MATHQQUEUE_HPP
#define MATHQQUEUE_HPP


#include <iostream>
#include <string>
#include "mathQuestion.hpp"


class Node{
 public:
    mathQuestion data;
    Node* next;
    Node* prev;


    Node(){
        next = nullptr;
        prev = nullptr;
        data;
    }


    Node(mathQuestion q){
        data = q;
        next = nullptr;
        prev = nullptr;
    }
};


class mathQQueue{
    public:
    Node* front;
    Node* back;


    mathQQueue(){
        front = nullptr;
        back = nullptr;
    }


    ~mathQQueue(){
        Node* current = front;
        while(current != nullptr){
            Node* temp = current;
            current = current->next;
            delete temp;
        }
    }


    void enqueue(mathQuestion newQ) {
        Node* newNode = new Node(newQ);
        if(isEmpty()){
            front = newNode;  // front -> [] <- back, both point to same node
            back = newNode;
        } else {
            // connect new node to the back of the queue.
            back->next = newNode;
            newNode->prev = back;
            back = newNode;
        }
    }


    void dequeue() {
        if(!isEmpty()){
            Node* temp = front;     // get a temparary refrence to the front node
            front = front->next;    // update front
            if(front != nullptr){
                front->prev = nullptr;  // set front's prev to nullptr
            } else {
                back = nullptr;         // update back, if the node removed is the last one.
            }
            delete temp;            // delete the node. If needed, it was accessed with frontNodeData method.
        }
    }


    bool isEmpty() {
        return (front == nullptr) && (back == nullptr);
    }
   
    Node* getFront(){
        return front;
    }
};
#endif