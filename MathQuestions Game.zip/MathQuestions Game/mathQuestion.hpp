#ifndef MATHQUESTION_HPP
#define MATHQUESTION_HPP
#include "raylib.h"
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>



class mathQuestion{
   public:
   int num;
   int answer;
   std::string question;




   mathQuestion(){
       num = 0;
       answer = 0;
       question;
   }




   mathQuestion(int n){
       int levelNum = n;
       if(levelNum==1){
           //randomize an addition question and have answer hold its answer
           srand(time(0));
           int num1 = rand() % 100;
           int num2 = rand() % 100;
           answer = num1 + num2;
           question = std::to_string(num1) + " + " + std::to_string(num2) + " = ?";
       }




       else if(levelNum==2){
           //randomize a subtraction question and have answer hold its answer
           srand(time(0));
           int num1 = rand() % 100;
           int num2 = rand() % 100;
           answer = num1 - num2;
           question = std::to_string(num1) + " - " + std::to_string(num2) + " = ?";
       }




       else if(levelNum==3){
           //randomize a multiplication question and have answer hold its answer
           srand(time(0));
           int num1 = rand() % 100;
           int num2 = rand() % 100;
           answer = num1 * num2;
           question = std::to_string(num1) + " * " + std::to_string(num2) + " = ?";
       }
   }
         
   bool isCorrect(int userA){
       return(userA==answer);
   }

   std::string getQuestion(){
       return question;
   }




};




#endif